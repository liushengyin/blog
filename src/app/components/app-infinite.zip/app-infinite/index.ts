export * from './app-infinite.component';
